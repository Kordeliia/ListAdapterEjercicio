package com.cursosandroidant.sports

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.cursosandroidant.sports.databinding.FragmentDetailBinding

/****
 * Project: Sports
 * From: com.cursosandroidant.sports
 * Created by Alain Nicolás Tello on 10/01/23 at 12:10
 * All rights reserved 2023.
 *
 * All my Udemy Courses:
 * https://www.udemy.com/user/alain-nicolas-tello/
 * And Frogames formación:
 * https://cursos.frogamesformacion.com/pages/instructor-alain-nicolas
 *
 * Web: www.alainnicolastello.com
 ***/
class DetailFragment : Fragment() {
    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var adapter: SportAdapter
    private lateinit var sport: Sport
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            sport = Sport(0,
                it.getString("name", "-"),
                it.getString("description", ""),
                it.getString("url", ""))
        }
    }
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvName.text = sport.name
        binding.tvDescription.text = sport.description
        Glide.with(this)
            .load(sport.imgUrl)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .centerCrop()
            .into(binding.imgCover)
        
        setupRecyclerView()
        getAllSports()
    }
    
    private fun setupRecyclerView() {
        adapter = SportAdapter()
        binding.recyclerView.apply {
            setHasFixedSize(true)
            adapter = this@DetailFragment.adapter
        }
    }
    
    private fun getAllSports() {
        val sportsData = FakeDatabase.sports()
        sportsData.forEach { sport ->
            adapter.add(sport)
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}